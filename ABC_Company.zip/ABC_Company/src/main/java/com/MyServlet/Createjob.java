package com.MyServlet;
 

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
 

/**
 * Servlet implementation class Createjob
 */
@WebServlet("/createjob")
public class Createjob extends HttpServlet {
private static final long serialVersionUID = 1L;
      
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Createjob() {
        super();
        // TODO Auto-generated constructor stub
    }
 

/**
* @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
*/
protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
// TODO Auto-generated method stub
// response.getWriter().append("Served at: ").append(request.getContextPath());
String title = request.getParameter("title");
        String jobtype = request.getParameter("type");
        String dept = request.getParameter("dept");
        String country = request.getParameter("country");
        String desc = request.getParameter("desc");
        String city = request.getParameter("city");
        String odate = request.getParameter("odate");
        
    int job_type_cd=0;
    int dept_id=0;
    int country_cd=0;
    
 

try {
Class.forName("org.postgresql.Driver");
} catch (ClassNotFoundException e) {
// TODO Auto-generated catch block
e.printStackTrace();
}
//     System.out.println("connection established now");
      try {
Connection connection=DriverManager.getConnection("jdbc:postgresql://localhost:5432/bydb","postgres","kathir");
String sql1="select * from job_types where job_type_name=?";
      
 

 

 

//         
try (PreparedStatement statementj = connection.prepareStatement(sql1)) {
    // Set the parameter value (you can set other parameters as needed)
    statementj.setString(1, jobtype);
 

    try (ResultSet resultSet = statementj.executeQuery()) {
        resultSet.next();
        job_type_cd = resultSet.getInt(1);
//         System.out.println("hii");
//         System.out.println(job_type_cd);
    }
} catch (SQLException e) {
    e.printStackTrace();
}
 

 

//department_id
String sql2="select * from department where dept_name=?";
      
 

 

 

//      
try (PreparedStatement statementd = ((Connection) connection).prepareStatement(sql2)) {
    // Set the parameter value (you can set other parameters as needed)
    statementd.setString(1, dept);
 

    try (ResultSet resultSet2 = statementd.executeQuery()) {
        resultSet2.next();
       dept_id = resultSet2.getInt(1);
//         System.out.println("hii");
//         System.out.println(dept_id);
    }
} catch (SQLException e) {
    e.printStackTrace();
}
 

 

 

String sql3="select * from country where country_name=?";
      
 

 

 

//      
try (PreparedStatement statement3 = ((Connection) connection).prepareStatement(sql3)) {
    // Set the parameter value (you can set other parameters as needed)
    statement3.setString(1, country);
 

    try (ResultSet resultSet3 = statement3.executeQuery()) {
        resultSet3.next();
       country_cd = resultSet3.getInt(1);
//         System.out.println("hii");
//         System.out.println(country_cd);
    }
} catch (SQLException e) {
    e.printStackTrace();
}
 

String sql = "INSERT INTO jobs (job_id,job_title,job_desc,job_type_cd,dept_id,job_status_cd,country_cd,date_opened) " +
                "VALUES (?,?, ?, ?, ?, ?, ?, ?)";
// System.out.println("yes");
PreparedStatement statement = ((Connection) connection).prepareStatement(sql);
Statement stmt=connection.createStatement();
ResultSet rs=stmt.executeQuery("select MAX(job_id) from jobs");
rs.next();
statement.setInt(1, rs.getInt(1)+1);
    statement.setString(2, title);
        statement.setString(3, desc);
        statement.setInt(4, job_type_cd);
        statement.setInt(5, dept_id);
        statement.setInt(6, 1);
        statement.setInt(7, country_cd);
        statement.setString(8, odate);
        statement.executeUpdate();
        
        request.getRequestDispatcher("/WEB-INF/success.jsp").forward(request, response);
} catch (SQLException e) {
// TODO Auto-generated catch block
e.printStackTrace();
}
//      System.out.println("connection established now2");
}
 

/**
* @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
*/
protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
// TODO Auto-generated method stub
//doGet(request, response);
}
 

}
