package com.MyServlet;

import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.Date;
import java.util.Objects;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

/**
 * Servlet implementation class ApplyJobservlet
 */
@WebServlet("/addApplyJob")
@MultipartConfig
public class ApplyJobservlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ApplyJobservlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
//		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
//		doGet(request, response);
		
		String fname=request.getParameter("fname");
		String lname=request.getParameter("lname");
		String email=request.getParameter("email");
		String phone=request.getParameter("phone");
		String address=request.getParameter("address");
		String city=request.getParameter("city");
		String state=request.getParameter("state");
		String zip=request.getParameter("zip");
		String country=request.getParameter("country");
		String eduLevel=request.getParameter("eduLevel");
		String eduType=request.getParameter("eduType");
		String cletter=request.getParameter("cletter");
		String employed=request.getParameter("employed");
		String cemployer=request.getParameter("cemployer");
		String[] type=request.getParameterValues("type");
		boolean flag=true;
		if(Objects.equals(employed,null)) {
			flag=false;
		}
		int experience=0;
		
		Part fileName=request.getPart("resume");
		System.out.println(fileName);
		InputStream fileContent=fileName.getInputStream();
		byte[] bytes=fileContent.readAllBytes();
		try {
			Class.forName("org.postgresql.Driver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Connection con;
		try {
			con = DriverManager.getConnection("jdbc:postgresql://localhost:5432/bydb","postgres","kathir");
			Statement stmt=con.createStatement();
			PreparedStatement pstmt=con.prepareStatement("insert into applicants values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
			ResultSet res=stmt.executeQuery("select MAX(appl_id) from applicants");
			res.next();
			pstmt.setInt(1,res.getInt(1)+1);
			pstmt.setString(2, fname);
			pstmt.setString(3,lname);
			pstmt.setString(4, email);
			pstmt.setString(5,phone);
			pstmt.setString(6, address);
			pstmt.setString(7,city);
			pstmt.setString(8, state);
			pstmt.setString(9,zip);
			
			System.out.println(country);
			PreparedStatement pstmt1 = con.prepareStatement("select * from country where country_name= ?");
			pstmt1.setString(1, country);
			ResultSet rs = pstmt1.executeQuery();
			rs.next();
			pstmt.setInt(10, rs.getInt(1));
			rs.close();
			
			ResultSet rs1=stmt.executeQuery("select * from apply_status_codes where status_desc='pending'");
			
			
			rs1.next();
			pstmt.setInt(11,1);
			rs1.close();
			
			pstmt1=con.prepareStatement("select * from education_levels where edu_level_name=?");
			pstmt1.setString(1, eduLevel);
			rs = pstmt1.executeQuery();
			rs.next();
			pstmt.setInt(12, rs.getInt(1));
			
			pstmt1=con.prepareStatement("select * from education_type where edu_type_name=?");
			pstmt1.setString(1, eduType);
			rs = pstmt1.executeQuery();
			rs.next();
			pstmt.setInt(13, rs.getInt(1));
			
			pstmt.setBytes(14, bytes);
			pstmt.setString(15,cletter);

			LocalDate currentDate = LocalDate.now();
			
			pstmt.setObject(16,currentDate);
			pstmt.setBoolean(17, flag);
			pstmt.setString(18, cemployer);
			pstmt.setInt(19, experience);
			pstmt.setObject(20, currentDate);
			pstmt.setString(21,fname+lname);
			
			pstmt.execute();
			
			request.getRequestDispatcher("/WEB-INF/success.jsp").forward(request, response);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		
		
	}

}
