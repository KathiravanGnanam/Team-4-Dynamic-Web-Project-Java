package com.MyServlet;

import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

/**
 * Servlet implementation class ApplyJobservlet
 */
@WebServlet("/addApplyJob")
public class ApplyJobservlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ApplyJobservlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
//		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
//		doGet(request, response);
		
		String fname=request.getParameter("fname");
		String lname=request.getParameter("lname");
		String email=request.getParameter("email");
		String phone=request.getParameter("phone");
		String address=request.getParameter("address");
		String city=request.getParameter("city");
		String state=request.getParameter("state");
		String zip=request.getParameter("zip");
		String country=request.getParameter("country");
		String eduLevel=request.getParameter("eduLevel");
		String eduType=request.getParameter("eduType");
		String cletter=request.getParameter("cletter");
		String employed=request.getParameter("employed");
		String cemployer=request.getParameter("cemployer");
		String type=request.getParameter("type");
		int experience=0;
		if(!request.getParameter("employed").equals(null)) {
			experience=Integer.parseInt(request.getParameter("experience"));
		}
		Part fileName=request.getPart("resume");
		InputStream fileContent=fileName.getInputStream();
		byte[] bytes=fileContent.readAllBytes();
		
		Connection con;
		try {
			con = DriverManager.getConnection("jdbc:postgresql://localhost:5432/bydb","postgres","kathir");
			Statement stmt=con.createStatement();
//			PreparedStatement pstmt=con.prepareStatement("insert into Employee values(?,?,?,?,?,?)");
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		
		
	}

}
